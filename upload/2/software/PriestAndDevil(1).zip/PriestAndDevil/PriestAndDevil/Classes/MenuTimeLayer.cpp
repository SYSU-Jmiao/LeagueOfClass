/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "MenuTimeLayer.h"
#include "VisibleRect.h"

#include "GameMainScene.h"

MenuTimeLayer* MenuTimeLayer::create(){
	MenuTimeLayer* obj = new MenuTimeLayer();
	if (obj->init()){
		obj->autorelease();
		return obj;
	}
	return NULL;
}

bool MenuTimeLayer::init(){
	float padding = 10;

	// Menu - Help Back
	CCMenuItem* helpItem = CCMenuItemImage::create("help_button_normal.png", "help_button_pressed.png", this, menu_selector(MenuTimeLayer::onHelpCallback));
	helpItem->setAnchorPoint(ccp(1, 1));
	helpItem->setPosition(ccpAdd(VisibleRect::rightTop(), ccp(-padding, -padding)));
	CCMenu* menu = CCMenu::create(helpItem, NULL);
	menu->setAnchorPoint(CCPointZero);
	menu->setPosition(CCPointZero);
	this->addChild(menu);

	// Time Counter
	m_restTime = 90.0f;
	m_timeLabel = CCLabelTTF::create("", "Arial", 64);
	m_timeLabel->setColor(ccc3(52, 199, 166));
	m_timeLabel->setAnchorPoint(ccp(0, 1));
	m_timeLabel->setPosition(VisibleRect::center());
	m_timeLabel->setPosition(ccpAdd(VisibleRect::leftTop(), ccp(padding, -padding)));
	this->addChild(m_timeLabel);

	// invoke function update every frame
	scheduleUpdate();

	return true;
}

void MenuTimeLayer::updateTimeLabel(float restTime) {
	char buffer[25];
	sprintf(buffer, "Time:%.1f", restTime);
	m_timeLabel->setString(buffer);
}

void MenuTimeLayer::update(float dt) {
	m_restTime -= dt;
	if (m_restTime <= 0) {
		m_restTime = 0;
		this->unscheduleUpdate();
		((GameMainScene*)this->getParent())->onTimeOver();
	}
	updateTimeLabel(m_restTime);
}
void MenuTimeLayer::onHelpCallback(CCObject* pSender) {
	((GameMainScene*)this->getParent())->onHelp();
}
 