/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Game_Main_Scene_H__
#define Game_Main_Scene_H__

#include "cocos2d.h"
#include "MenuTimeLayer.h"
#include "GameMainLayer.h"
USING_NS_CC;

class GameMainScene :public CCScene {
public:
	static GameMainScene* create();
	virtual bool init();
	void onTimeOver();
	void onGameDefeat();
	void onGameVictory();
	void onHelp();
	void onUpdateTime();
	void onStopUpdateTime();
protected:
	MenuTimeLayer* m_menu_time;
	GameMainLayer* m_main_layer;
	void popPage(std::string msg);
};

#endif
