/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "GameHelper.h"

std::string GameHelper::NextOperation(int nPriest, int nDevil, bool left) {
	if (left) {
		if (nPriest == 3 && nDevil == 3) {
			return "Transport Two devils Right";
		} else if (nPriest == 3 && nDevil == 2) {
			return "Transport Two devils Right";
		} else if (nPriest == 3 && nDevil == 1) {
			return "Transport Two Priests Right";
		} else if (nPriest == 2 && nDevil == 2) {
			return "Transport Two Priests Right";
		} else if (nPriest == 1 && nDevil == 1) {
			return "Transport One Priest and One Devil Right";
		} else if (nPriest == 0 && nDevil == 3) {
			return "Transport Two Devils Right";
		} else if (nPriest == 0 && nDevil == 2) {
			return "Transport Two Devils Right";
		} else if (nPriest == 0 && nDevil == 1) {
			return "Transport One Devils Right";
		}
	} else {
		if (nPriest == 3 && nDevil == 2) {
			return "Transport One Devil Left";
		} else if (nPriest == 3 && nDevil == 1) {
			return "Transport One Devil Left";
		} else if (nPriest == 3 && nDevil == 0) {
			return "Transport One Devil Left";
		} else if (nPriest == 2 && nDevil == 2) {
			return "Transport One Priest Left";
		} else if (nPriest == 1 && nDevil == 1) {
			return "Transport One Priest and One Devil Left";
		} else if (nPriest == 0 && nDevil == 2) {
			return "Transport One Devil Left";
		} else if (nPriest == 0 && nDevil == 1) {
			return "Transport One Devil Left";
		}
	}
	return "Error";
}
