/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Pop_Page_Layer_H__
#define Pop_Page_Layer_H__

#include "cocos2d.h"
USING_NS_CC;

class PopPageLayer :public CCLayer{
public:
	static PopPageLayer* create(const std::string msg);
	virtual bool init(const std::string msg);
	virtual bool ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent);
protected:
	void onBackCallback(CCObject* pSender);
	void onReplayCallback(CCObject* pSender);
};

#endif
