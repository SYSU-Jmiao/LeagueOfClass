/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "GameStartScene.h"
#include "GameMainScene.h"

bool GameStartScene::init() {
	CCSize winSize = CCDirector::sharedDirector()->getWinSize();

	CCSprite* bg = CCSprite::create("intro_scene_bg.png");
	bg->setAnchorPoint(CCPointZero);
	bg->setPosition(CCPointZero);
	this->addChild(bg);

	CCMenuItem* playItem = CCMenuItemImage::create("play_button_normal.png", "play_button_pressed.png", this, menu_selector(GameStartScene::onPlayCallback));
	playItem->setPosition(ccp(winSize.width * 0.75, winSize.height * 0.5));
	CCScaleBy* scaleBy = CCScaleBy::create(1.0f, 1.1f, 1.1f);
	CCScaleBy* scaleBack = (CCScaleBy*)scaleBy->reverse();
	CCEaseBackOut* scaleByEase = CCEaseBackOut::create(scaleBy);
	CCSequence* seq = CCSequence::create(scaleByEase, scaleBack, NULL);
	playItem->runAction(CCRepeat::create(seq,-1));

	CCMenu* menu = CCMenu::create(playItem, NULL);
	menu->setAnchorPoint(CCPointZero);
	menu->setPosition(CCPointZero);
	this->addChild(menu);

	return true;
}

void GameStartScene::onPlayCallback(CCObject* pSender) {
	CCScene* scene = GameMainScene::create();
	CCDirector::sharedDirector()->pushScene(scene);
}

GameStartScene* GameStartScene::create() {
	GameStartScene* obj = new GameStartScene();
	if (obj->init()) {
		obj->autorelease();
		return obj;
	}
	return NULL;
}

