/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "Boat.h"
#include "Role.h"

Boat* Boat::create() {
	Boat* obj = new Boat();
	if (obj->init()){
		obj->autorelease();
		return obj;
	}
	return NULL;
}

bool Boat::init() {
	m_is_ready_go = false;
	m_is_on_left_land = true;
	m_is_moving = false;
	m_left_role = m_right_role = NULL;

	CCSprite* sprite = CCSprite::create("boat.png");
	sprite->setAnchorPoint(CCPointZero);
	sprite->setPosition(CCPointZero);
	this->addChild(sprite);

	this->setContentSize(sprite->getContentSize());
	return true;
}

void Boat::FinishJump() {
	if (!isEmpty()) {
		m_is_ready_go = true;
	}
}

bool Boat::hasEmpty() {
	return m_left_role == NULL || m_right_role == NULL;
}
bool Boat::isEmpty() {
	return m_left_role == NULL && m_right_role == NULL;
}

void Boat::pushRole(Role* role) {

	CCSize contentSize = this->getContentSize();

	role->retain();
	CCPoint preParentPos = role->getPosition();
	CCPoint preWorldPos = role->getParent()->convertToWorldSpace(preParentPos);
	role->removeFromParent();

	CCPoint preLocalPos = this->convertToNodeSpace(preWorldPos);
	role->setPosition(preLocalPos);
	this->addChild(role);
	role->release();

	CCPoint jumpToPos;
	if (m_left_role == NULL) {
		jumpToPos = ccp(contentSize.width / 3, contentSize.height);
		m_left_role = role;
	} else {
		jumpToPos = ccp(contentSize.width / 3 * 2, contentSize.height);
		m_right_role = role;
	}
	role->runAction(CCSequence::create(
		CCJumpTo::create(1.0, jumpToPos, role->getContentSize().height, 1),
		CCCallFunc::create(this, callfunc_selector(Boat::FinishJump)),
		NULL
		));
}
void Boat::removeRole(Role* role) {
	if (role == m_left_role) {
		this->removeChild(m_left_role);
		m_left_role = NULL;
	} else if (role == m_right_role) {
		this->removeChild(m_right_role);
		m_right_role = NULL;
	}

	if (isEmpty()) {
		m_is_ready_go = false;
	}
}

void Boat::startMove() {
	m_is_moving = true;
}
void Boat::stopMove() {
	m_is_moving = false;
	m_is_on_left_land = !m_is_on_left_land;
}
