/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Role_H__
#define Role_H__

#include "cocos2d.h"
USING_NS_CC;

class Role :public CCNode {
public:
	static Role* create(bool is_priest);
	virtual bool init(bool is_priest);
	bool isClickOnMe(CCPoint worldPoint);
protected:
	// devil or priest
	CC_SYNTHESIZE_READONLY(bool, m_is_priest, IsPriest);
	// place role in different position
	CC_SYNTHESIZE(int, m_index, Index);
};

#endif
