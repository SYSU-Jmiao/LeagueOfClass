/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Game_Start_Scene_H__
#define Game_Start_Scene_H__

#include "cocos2d.h"
USING_NS_CC;

class GameStartScene :public CCScene {
public:
	static GameStartScene* create();
	virtual bool init();
protected:
	void onPlayCallback(CCObject* pSender);
};

#endif
