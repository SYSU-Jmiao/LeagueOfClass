/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Boat_H__
#define Boat_H__

#include "cocos2d.h"
#include "Role.h"
USING_NS_CC;

class Boat :public CCNode {
protected:
	CC_SYNTHESIZE_READONLY(bool, m_is_ready_go, IsReadyGo);
	CC_SYNTHESIZE_READONLY(bool, m_is_on_left_land, IsOnLeftLand);
	CC_SYNTHESIZE_READONLY(bool, m_is_moving, IsMoving);
	CC_SYNTHESIZE_READONLY(Role*, m_left_role, LeftRole);
	CC_SYNTHESIZE_READONLY(Role*, m_right_role, RightRole);
	void FinishJump();
public:
	static Boat* create();
	virtual bool init();

	void pushRole(Role* role);
	void removeRole(Role* role);
	void startMove();
	void stopMove();
	bool hasEmpty();
	bool isEmpty();
};

#endif
