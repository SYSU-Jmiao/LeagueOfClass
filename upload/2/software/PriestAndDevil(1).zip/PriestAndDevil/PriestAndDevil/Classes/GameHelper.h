/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Game_Helper_H__
#define Game_Helper_H__

#include <string>

class GameHelper{
public:
	static std::string NextOperation(int nPriest, int nDevil, bool left);
};

#endif
