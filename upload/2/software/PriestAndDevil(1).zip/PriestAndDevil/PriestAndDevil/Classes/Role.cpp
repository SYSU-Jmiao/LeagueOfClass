/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "Role.h"

bool Role::init(bool is_priest) {
	CCSprite* sp = NULL;
	if (!is_priest) {
		sp = CCSprite::create("devil.png");
	} else if (is_priest) {
		sp = CCSprite::create("priest.png");
	} else {
		return false;
	}
	sp->setAnchorPoint(CCPointZero);
	sp->setPosition(CCPointZero);
	this->addChild(sp);

	this->m_is_priest = is_priest;
	m_index = 0;

	this->setContentSize(sp->getContentSize());

	return true;
}

bool Role::isClickOnMe(CCPoint worldPoint) {
	CCSize contentSize = this->getContentSize();
	CCPoint localPoint = this->convertToNodeSpace(worldPoint);
	return localPoint.x >= 0 && localPoint.x<contentSize.width && localPoint.y >= 0 && localPoint.y<contentSize.height;
}

Role* Role::create(bool is_priest) {
	Role* obj = new Role();
	if (obj->init(is_priest)) {
		obj->autorelease();
		return obj;
	}
	return NULL;
}
