/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "PopPageLayer.h"
#include "GameMainScene.h"

void PopPageLayer::onBackCallback(CCObject* pSender) {
	((GameMainScene*)this->getParent())->onUpdateTime();
	this->removeFromParentAndCleanup(true);
}

void PopPageLayer::onReplayCallback(CCObject* pSender) {
	CCDirector::sharedDirector()->replaceScene(GameMainScene::create());
}

bool PopPageLayer::init(const std::string msg) {
	CCSize winSize = CCDirector::sharedDirector()->getWinSize();

	CCLayerColor* bg1 = CCLayerColor::create(ccc4(50, 50, 50, 150));
	this->addChild(bg1);

	CCLayerColor* bg2 = CCLayerColor::create(ccc4(255, 255, 255, 255));
	bg2->ignoreAnchorPointForPosition(false);
	bg2->setContentSize(CCSize(winSize.width * 0.5, winSize.height * 0.5 + 100));
	bg2->setAnchorPoint(ccp(0.5, 0.5));
	bg2->setPosition(ccp(winSize.width * 0.5, winSize.height * 0.5));
	this->addChild(bg2);

	CCLabelTTF* title = CCLabelTTF::create(msg.c_str(), "Arial", 56, CCSize(winSize.width/2,winSize.height/2+100),kCCTextAlignmentCenter);
	title->setAnchorPoint(ccp(0.5,1));
	title->setColor(ccc3(52, 199, 166));
	title->setPosition(ccp(winSize.width * 0.5, winSize.height*0.75));
	this->addChild(title);

	CCMenuItem* item = NULL;
	if (msg == "You Win" || msg == "You Lose" || msg == "Time Over") {
		item = CCMenuItemImage::create("replay_button_normal.png", "replay_button_pressed.png", this, menu_selector(PopPageLayer::onReplayCallback));
	} else {
		item = CCMenuItemImage::create("back_button_normal.png", "back_button_pressed.png", this, menu_selector(PopPageLayer::onBackCallback));
	}
	CCMenu* menu = CCMenu::create(item, NULL);
	menu->setPosition(ccp(winSize.width * 0.5, winSize.height * 0.3));
	this->addChild(menu);

	this->setTouchEnabled(true);
	CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, menu->getTouchPriority(), true);
	return true;
}

PopPageLayer* PopPageLayer::create(const std::string msg) {
	PopPageLayer* obj = new PopPageLayer();
	if (obj->init(msg)) {
		obj->autorelease();
		return obj;
	}
	return NULL;
}

bool PopPageLayer::ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent) {
	return true;
}
