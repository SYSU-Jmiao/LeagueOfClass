/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Game_Main_Layer_H__
#define Game_Main_Layer_H__

#include "cocos2d.h"
#include "Role.h"
#include "Boat.h"
USING_NS_CC;

class GameMainLayer :public CCLayer{
public:
	static GameMainLayer* create();
	virtual bool init();
	virtual bool ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent);
	int countLeftLandPriest();
	int countLeftLandDevil();
	bool isOnLeftLand();
protected:
	Boat* m_boat;
	CCArray* m_left_roles;
	CCArray* m_right_roles;
	CCPoint m_left_land_pos;
	CCPoint m_right_land_pos;
	CCSprite* m_left_land_sprite;
	CCSprite* m_right_land_sprite;
protected:
	void onGoCallback(CCObject* pSender);
	void onBoatReachLand();
	void checkAndCollectRole(Role* role, CCArray* priests, CCArray* devils);
	void collectLeftLandRole(CCArray* priestArr, CCArray* devilArr);
	void collectRightLandRole(CCArray* priestArr, CCArray* devilArr);
	float caculateLandPointXLeft(Role* role, float landWidth);
	float caculateLandPointXRight(Role* role, float landWidth);
	bool checkLeftLand();
	bool checkRightLand();
	void jumpOut(Role* role);
	void die(CCArray* roleArr);
};

#endif
