/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#ifndef Menu_Time_Layer_H__
#define Menu_Time_Layer_H__

#include "cocos2d.h"
USING_NS_CC;

class MenuTimeLayer :public CCLayer{
public:
	static MenuTimeLayer* create();
	virtual void update(float delta);
	virtual bool init();
protected:
	CCLabelTTF* m_timeLabel;
	void updateTimeLabel(float restTime);
	void onHelpCallback(CCObject* pSender);
private:
	float m_restTime;
};

#endif
