/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "GameMainLayer.h"
#include "VisibleRect.h"
#include "Boat.h"
#include "Role.h"

#include "GameMainScene.h"

enum {
	kZOrder_role,
	kZOrder_Boat,
	kZOrder_WaterWave,
	kZOrder_Land,
	kZOrder_Go,
};

float GameMainLayer::caculateLandPointXLeft(Role* role, float landWidth) {
	float padding = 10;
	float roleWidth = (landWidth - padding * 2) / 6;
	int index = role->getIndex();
	float leftPosX = padding + index*roleWidth + roleWidth / 2;
	return leftPosX;
}
float GameMainLayer::caculateLandPointXRight(Role* role, float landWidth) {
	return landWidth - caculateLandPointXLeft(role, landWidth);
}

void GameMainLayer::checkAndCollectRole(Role* role, CCArray* priests, CCArray* devils) {
	if (role != NULL) {
		if (!role->getIsPriest()) {
			devils->addObject(role);
		} else {
			priests->addObject(role);
		}
	}
}

void GameMainLayer::die(CCArray* roleArr) {
	for (unsigned int i = 0; i < roleArr->count(); ++ i) {
		Role* role = (Role*)roleArr->objectAtIndex(i);
		CCSize roleSize = role->getContentSize();
		CCJumpBy* jumpBy = CCJumpBy::create(1.0, ccp(0, -roleSize.height / 2), roleSize.height, 1);
		role->runAction(jumpBy);
	}
}

GameMainLayer* GameMainLayer::create() {
	GameMainLayer* obj = new GameMainLayer();
	if (obj->init()){
		obj->autorelease();
		return obj;
	}
	return NULL;
}

bool GameMainLayer::init() {
	float padding = 10;
	//create the Go-Menu
	CCMenuItem* goItem = CCMenuItemImage::create("go_button_normal.png", "go_button_pressed.png", this, menu_selector(GameMainLayer::onGoCallback));
	goItem->setAnchorPoint(ccp(0.5, 1));
	goItem->setPosition(ccpAdd(VisibleRect::top(), ccp(0, -padding)));
	CCMenu* menu = CCMenu::create(goItem, NULL);
	menu->setAnchorPoint(CCPointZero);
	menu->setPosition(CCPointZero);
	this->addChild(menu, kZOrder_Go);

	//create water wave
	CCSprite* waterWave = CCSprite::create("water_wave.png");
	waterWave->setAnchorPoint(ccp(0, 0));
	waterWave->setPosition(ccp(0, 0));
	this->addChild(waterWave, kZOrder_WaterWave);

	//create the land
	m_left_land_sprite = CCSprite::create("left_land.png");
	m_left_land_sprite->retain();
	m_left_land_sprite->setAnchorPoint(ccp(0, 0));
	m_left_land_sprite->setPosition(VisibleRect::leftBottom());
	this->addChild(m_left_land_sprite, kZOrder_Land);

	m_right_land_sprite = CCSprite::create("left_land.png");
	m_right_land_sprite->retain();
	m_right_land_sprite->setFlipX(true);
	m_right_land_sprite->setAnchorPoint(ccp(1, 0));
	m_right_land_sprite->setPosition(VisibleRect::rightBottom());
	this->addChild(m_right_land_sprite, kZOrder_Land);

	// create boat
	m_boat = Boat::create();
	m_boat->setAnchorPoint(ccp(0.5, 0.5));
	this->addChild(m_boat, kZOrder_Boat);
	m_boat->retain();

	//animate the water wave
	CCSize landSize = m_left_land_sprite->getContentSize();
	CCMoveBy* moveBy = CCMoveBy::create(landSize.width / 2 / 10, ccp(landSize.width / 2, 0));
	CCMoveBy* moveBack = (CCMoveBy*)moveBy->reverse();
	CCSequence* seq = CCSequence::create(moveBy, moveBack, NULL);
	waterWave->runAction(CCRepeatForever::create(seq));

	//init boat position and land side
	CCSize boatSize = m_boat->getContentSize();
	float boatPosY = landSize.height - boatSize.height / 2 - 10;
	m_left_land_pos = ccpAdd(VisibleRect::leftBottom(), ccp(landSize.width + boatSize.width / 2 + 10, boatPosY));
	m_right_land_pos = ccpAdd(VisibleRect::rightBottom(), ccp(-landSize.width - boatSize.width / 2 - 10, boatPosY));
	m_boat->setPosition(m_left_land_pos);

	//create roles
	m_left_roles = CCArray::create();
	m_left_roles->retain();
	for (int i = 0; i < 3; ++ i) {
		Role* role = Role::create(false);
		role->setIndex(i);
		role->setAnchorPoint(ccp(0.5, 0));
		CCPoint landPosInWorld = m_left_land_sprite->convertToWorldSpace(ccp(caculateLandPointXLeft(role, landSize.width), landSize.height));
		CCPoint landPosInThis = this->convertToNodeSpace(landPosInWorld);
		role->setPosition(landPosInThis);
		this->addChild(role);
		m_left_roles->addObject(role);
	}
	for (int i = 0; i < 3; ++ i) {
		Role* role = Role::create(true);
		role->setIndex(i + 3);
		role->setAnchorPoint(ccp(0.5, 0));
		CCPoint landPosInWorld = m_left_land_sprite->convertToWorldSpace(ccp(caculateLandPointXLeft(role, landSize.width), landSize.height));
		CCPoint landPosInThis = this->convertToNodeSpace(landPosInWorld);
		role->setPosition(landPosInThis);
		this->addChild(role);
		m_left_roles->addObject(role);
	}

	m_right_roles = CCArray::create();
	m_right_roles->retain();

	// add to touch dispathcher
	CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, getTouchPriority(), false);
	return true;
}
bool GameMainLayer::ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent){
	CCPoint worldPoint = pTouch->getLocation();

	if (m_boat->getIsMoving()) {
		return false;
	}

	if (m_boat->getIsOnLeftLand()) {
		for (unsigned int i = 0; i < m_left_roles->count(); ++i) {
			Role* role = (Role*)m_left_roles->objectAtIndex(i);
			if (role->isClickOnMe(worldPoint) && m_boat->hasEmpty()) {
				m_boat->pushRole(role);
				m_left_roles->removeObject(role);
				return false;
			}
		}
	} else {
		for (unsigned int i = 0; i < m_right_roles->count(); ++i) {
			Role* role = (Role*)m_right_roles->objectAtIndex(i);
			if (role->isClickOnMe(worldPoint) && m_boat->hasEmpty()) {
				m_boat->pushRole(role);
				m_right_roles->removeObject(role);
				return false;
			}
		}
	}

	Role* leftRole = m_boat->getLeftRole();
	Role* rightRole = m_boat->getRightRole();
	if (leftRole && leftRole->isClickOnMe(worldPoint)) {
		jumpOut(leftRole);
	}
	if (rightRole && rightRole->isClickOnMe(worldPoint)) {
		jumpOut(rightRole);
	}

	return false;
}
void GameMainLayer::onGoCallback(CCObject* pSender){
	if (m_boat->getIsReadyGo() && !m_boat->getIsMoving()) {
		m_boat->startMove();
		CCPoint targetPos;
		if (m_boat->getIsOnLeftLand()) {
			targetPos = m_right_land_pos;
		} else {
			targetPos = m_left_land_pos;
		}
		m_boat->runAction(CCSequence::create(
			CCMoveTo::create(1.0, targetPos),
			CCCallFunc::create(this, callfunc_selector(GameMainLayer::onBoatReachLand)),
			NULL
		));
		bool okay;
		if (m_boat->getIsOnLeftLand()) {
			okay = checkLeftLand();
		} else {
			okay = checkRightLand();
		}
		if (!okay) {
			((GameMainScene*)this->getParent())->onGameDefeat();
		}
	}
}
void GameMainLayer::collectLeftLandRole(CCArray* priestArr, CCArray* devilArr){
	for (unsigned int i = 0; i < m_left_roles->count(); ++i) {
		Role* role = (Role*)m_left_roles->objectAtIndex(i);
		checkAndCollectRole(role, priestArr, devilArr);
	}
	if (!m_boat->getIsMoving() && m_boat->getIsOnLeftLand()) {
		checkAndCollectRole(m_boat->getLeftRole(), priestArr, devilArr);
		checkAndCollectRole(m_boat->getRightRole(), priestArr, devilArr);
	}
}
void GameMainLayer::collectRightLandRole(CCArray* priestArr, CCArray* devilArr){
	for (unsigned int i = 0; i < m_right_roles->count(); ++i) {
		Role* role = (Role*)m_right_roles->objectAtIndex(i);
		checkAndCollectRole(role, priestArr, devilArr);
	}
	if (!m_boat->getIsMoving() && !m_boat->getIsOnLeftLand()) {
		checkAndCollectRole(m_boat->getLeftRole(), priestArr, devilArr);
		checkAndCollectRole(m_boat->getRightRole(), priestArr, devilArr);
	}
}
int GameMainLayer::countLeftLandPriest() {
	CCArray* priests = CCArray::create();
	CCArray* devils = CCArray::create();
	collectLeftLandRole(priests, devils);
	return priests->count();
}
int GameMainLayer::countLeftLandDevil(){
	CCArray* priests = CCArray::create();
	CCArray* devils = CCArray::create();
	collectLeftLandRole(priests, devils);
	return devils->count();
}
bool GameMainLayer::checkLeftLand(){
	CCArray* priests = CCArray::create();
	CCArray* devils = CCArray::create();
	collectLeftLandRole(priests, devils);
	CCLog("Left %d %d\n", priests->count(), devils->count());
	if (priests->count() > 0 && devils->count()>priests->count()) {
		die(priests);
		return false;
	}
	return true;
}
bool GameMainLayer::checkRightLand(){
	CCArray* priests = CCArray::create();
	CCArray* devils = CCArray::create();
	collectRightLandRole(priests, devils);
	CCLog("Right %d %d\n", priests->count(), devils->count());
	if (priests->count() > 0 && devils->count() > priests->count()) {
		die(priests);
		return false;
	}
	return true;
}

void GameMainLayer::jumpOut(Role* role) {
	role->retain();

	CCPoint preWorldPos = role->getParent()->convertToWorldSpace(role->getPosition());
	CCPoint prePosInThis = this->convertToNodeSpace(preWorldPos);
	CCSize landSize = m_left_land_sprite->getContentSize();
	
	float landPointX = 0.0f;
	if (m_boat->getIsOnLeftLand()) {
		landPointX = caculateLandPointXLeft(role, landSize.width);
	} else {
		landPointX = caculateLandPointXRight(role, landSize.width);
	}
	CCPoint landPosInWorld;
	if (m_boat->getIsOnLeftLand()) {
		landPosInWorld = m_left_land_sprite->convertToWorldSpace(ccp(landPointX, landSize.height));
		m_left_roles->addObject(role);
	} else {
		landPosInWorld = m_right_land_sprite->convertToWorldSpace(ccp(landPointX, landSize.height));
		m_right_roles->addObject(role);
	}

	m_boat->removeRole(role);
	role->setPosition(prePosInThis);
	this->addChild(role, kZOrder_role);

	CCPoint landPosInThis = this->convertToNodeSpace(landPosInWorld);
	CCJumpTo* jumpTo = CCJumpTo::create(1.0, landPosInThis, role->getContentSize().height, 1);
	role->runAction(jumpTo);

	role->release();

	if (m_right_roles->count() == 6) {
		((GameMainScene*)this->getParent())->onGameVictory();
	}
}

void GameMainLayer::onBoatReachLand() {
	bool okay;
	m_boat->stopMove();
	if (m_boat->getIsOnLeftLand()) {
		okay = checkLeftLand();
	} else {
		okay = checkRightLand();
	}
	if (!okay) {
		((GameMainScene*)this->getParent())->onGameDefeat();
	}
}

bool GameMainLayer::isOnLeftLand(){
	return m_boat->getIsOnLeftLand();
}
