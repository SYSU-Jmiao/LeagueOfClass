/**
* @author  jasison
* @email   jasison27@gmail.com
* @website http://www.jiangshan27.com
*/

#include "GameMainScene.h"
#include "VisibleRect.h"
#include "GameHelper.h"
#include "PopPageLayer.h"

enum {
	kZorder_BG,
	kZOrder_MainLayer,
	kZOrder_MenuTimeLayer,
	kZOrder_PopPage,
};

GameMainScene* GameMainScene::create() {
	GameMainScene* obj = new GameMainScene();
	if (obj->init()) {
		obj->autorelease();
		return obj;
	}
	return NULL;
}
bool GameMainScene::init() {
	CCLayerColor* bg = CCLayerColor::create(ccc4(255, 255, 255, 255));
	bg->setAnchorPoint(CCPointZero);
	bg->setPosition(CCPointZero);
	this->addChild(bg, kZorder_BG);

	m_main_layer = GameMainLayer::create();
	this->addChild(m_main_layer, kZOrder_MainLayer);
	
	m_menu_time = MenuTimeLayer::create();
	this->addChild(m_menu_time, kZOrder_MenuTimeLayer);

	return true;
}
void GameMainScene::onUpdateTime() {
	m_menu_time->scheduleUpdate();
}
void GameMainScene::onStopUpdateTime() {
	m_menu_time->unscheduleUpdate();
}
void GameMainScene::popPage(const std::string msg){
	CCSize ws = CCDirector::sharedDirector()->getWinSize();
	this->onStopUpdateTime();
	PopPageLayer* layer = PopPageLayer::create(msg);
	layer->setAnchorPoint(CCPointZero);
	layer->setPosition(ccp(0, -ws.height));
	this->addChild(layer, kZOrder_PopPage);

	CCMoveBy* moveBy = CCMoveBy::create(1.0, ccp(0, ws.height));
	CCEaseBackOut* moveByBack = CCEaseBackOut::create(moveBy);
	layer->runAction(moveByBack);
}

void GameMainScene::onTimeOver(){
	popPage("Time Over");
}
void GameMainScene::onGameDefeat(){
	popPage("You Lose");
}
void GameMainScene::onGameVictory(){
	popPage("You Win");
}
void GameMainScene::onHelp(){
	popPage(GameHelper::NextOperation(m_main_layer->countLeftLandPriest(), m_main_layer->countLeftLandDevil(), m_main_layer->isOnLeftLand()));
}
